<?php

if (!defined('ABSPATH')) exit;

require_once get_template_directory() . '/includes/theme-setup.php';
